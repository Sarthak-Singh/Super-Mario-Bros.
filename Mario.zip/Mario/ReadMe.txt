--------------------------------------------------------------------------------
Developer - Sarthak Singh aka GHOST
Super Mario Bros.
July 2020
README.TXT 
--------------------------------------------------------------------------------

This game recreates the World 1-1 from the original Super Mario Bros' game, with
some added features. 

--------------------------------------------------------------------------------

1. Known Problems
   
   There might be some glitches. The game's not pixel perfect. 

   1.1.One of the those is, unlike the original Mario, the player has to have 
       inertia to climb over objects.So if Mario doesn't climb the objects and 
       just jumps straight up even after pressing the direction keys, you'll need 
       to have a small runup before jumping. (Not exactly a glitch)

   1.2.The major problem is, after colliding with objects, the player stops going 
       in that, direction, even the object isn't in its path anymore. Just tapping 
       or going in the opposite direction fixes this.
          This game has been completed after a long period of time with several 
       breaks due to many reasons(placement session/ exams/ etc.), hence due to 
       different coding styles and ideas at every time, this glitch was supposed 
       to be fixed in the beginning only. Correcting it now will lead to changing 
       a lot of code and too much of extra work. Hence, I let it be.

   1.3 The hidden objects, like 1UP, powerups (Mushroom & Flower) are all there,
       just except the star of invincibility as, for that, 3 more sets of Mario
       sprites have to be handled, just for those 30 secs. If I would've been 
       making the full game with all the levels, it would've been included.

--------------------------------------------------------------------------------

2. Added Features.

   The scoring system and the rest of the things are similar to the original,
   just with these few additions.

   2.1.Since there is only 1 level, hence, the top score is analyzed after every 
       game, in the same session.
   2.2.The top score is not stored for a new start of the game (just like the 
       original), as storing it in a file serves no purpose as it can be modified 
       easily. (I know there are ways around that too..  But.. extra work..)
   2.3.The main added thing is in scoring. Now the rest of the scoring is same, 
       stomping the goombas in a domino affect increases the score count by 100 
       for each ( i.e. 100-200-300-400-and so on..) The flag and the koopa troopas 
       also gives the same score as the original. The added change is that at the 
       end of the game, after the time score has been added and the victory flag 
       from the castle is raised, extra points are given for the remaining lives 
       (because, why not) as 2000*remaining lives.
       This affects the score considerably and hence players will have to decide, 
       whether to save lives and complete the game somehow, or to lose 1 and go 
       back to gain the leftover points from the bricks, coins or even the enemies.

--------------------------------------------------------------------------------

Rest you'll figure out after playing. Enjoy. 

PS. If you find some other glitches, pls inform me.